package com.cg.spring.boot.jpa.springbootdatajpa.bean;

import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<Product, String>{
	
	
	
	
}
