package com.capgemini.conferencereg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PaymentsDetailsBean {

	@FindBy(how=How.ID,id="txtCardholderName")
	private WebElement cardHolderName;
	
	@FindBy(how=How.ID,id="txtDebit")
	private WebElement debit;
	
	@FindBy(how=How.ID,id="txtCvv")
	private WebElement cVV;

	@FindBy(how=How.ID, id="txtMonth")
	private WebElement month;
	
	@FindBy(how=How.NAME,name="year")
	private WebElement year;
	
	@FindBy(how=How.ID,id="btnPayment")
	private WebElement payment;
	
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}
	public String getCardHolderName() {
		return this.cardHolderName.getAttribute("value");
	}
	public void setdebit(String debit) {
		this.debit.sendKeys(debit);
	}
	public void setCvv(String cVV)
	{
		this.cVV.sendKeys(cVV);
	}
	public void setMonth(String month)
	{
		this.month.sendKeys(month);
	}
	public void setYear(String year)
	{
		this.year.sendKeys(year);
	}
	public void setPayment() {
		payment.click();;
	}
	
}
