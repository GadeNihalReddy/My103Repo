package com.capgemini.conferencereg.stepdef;


import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.conferencereg.bean.ConferenceRoomBookingPageBean;
import com.capgemini.conferencereg.bean.PaymentsDetailsBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDefinition {

	private WebDriver driver,driver1;
	private ConferenceRoomBookingPageBean pageBean ;
	private PaymentsDetailsBean pageBean1;
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver_win32\\chromedriver.exe");
		
	}
	
	@Given("^User is on conference room booking page$")
	public void user_is_on_conference_room_booking_page() throws Throwable {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://localhost:9098/Selenium/ConferenceRegistartion.html");
		pageBean= new ConferenceRoomBookingPageBean();
		PageFactory.initElements(driver, pageBean);
	}

	@When("^User selects 'Next' link without entering 'FirstName'$")
	public void user_selects_Next_link_without_entering_FirstName() throws Throwable {
	
		pageBean.clickNextPageLink();
		
	}

	@Then("^'Please fill the FirstName' message should display$")
	public void please_fill_the_FirstName_message_should_display() throws Throwable {
	  
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the First Name";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User selects 'Next' link without entering 'LastName'$")
	public void user_selects_Next_link_without_entering_LastName() throws Throwable {
		
		driver.switchTo().alert().dismiss();
		
		pageBean.setFirstName("Nihal");
		pageBean.clickNextPageLink();
	}

	@Then("^'Please fill the Last Name' message should display$")
	public void please_fill_the_Last_Name_message_should_display() throws Throwable {
	    
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Last Name";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User selects 'Next' link after entering invalid 'Email' address$")
	public void user_selects_Next_link_after_entering_invalid_Email_address() throws Throwable {
	
		driver.switchTo().alert().dismiss();
		
		pageBean.setLastName("Gade");
	
		pageBean.setEmail("srinivas.a.kolaparthi capgemini.com");
		pageBean.clickNextPageLink();
		
	}

	@Then("^'Please enter valid Email Id' message should display$")
	public void please_enter_valid_Email_Id_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please enter valid Email Id.";
		Assert.assertEquals(expectedMessage, actualMessage);
	 
	}

	@When("^User selects 'Next' link without entering 'Contact No'$")
	public void user_selects_Next_link_without_entering_Contact_No() throws Throwable {
		driver.switchTo().alert().dismiss();
		
		pageBean.setEmail("srinivas.a.kolaparthi@capgemini.com");
		pageBean.clickNextPageLink();
		
	}

	@Then("^'Please fill the Contact No' message should display$")
	public void please_fill_the_Contact_No_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Contact No.";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User selects 'Next' link after entering invalid 'Contact No'$")
	public void user_selects_Next_link_after_entering_invalid_Contact_No() throws Throwable {

		driver.switchTo().alert().dismiss();
		
		pageBean.setContactNo("123456789");
		pageBean.clickNextPageLink();
		
	}

	@Then("^'Please enter valid Contact no' message should display$")
	public void please_enter_valid_Contact_no_message_should_display() throws Throwable {
		
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please enter valid Contact no.";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User selects 'Next' link without selecting  'Number of people attending'$")
	public void user_selects_Next_link_without_selecting_Number_of_people_attending() throws Throwable {

		driver.switchTo().alert().dismiss();
		pageBean.setContactNo("8008746024");
		
		pageBean.clickNextPageLink();
		
	}

	@Then("^'Please fill the Number of people attending' message should display$")
	public void please_fill_the_Number_of_people_attending_message_should_display() throws Throwable {

		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Number of people attending";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User selects 'Next' link without entering  'Building Name & Room No'$")
	public void user_selects_Next_link_without_entering_Building_Name_Room_No() throws Throwable {
		
		driver.switchTo().alert().dismiss();
		pageBean.setNoOfPerson("3");
		
		pageBean.clickNextPageLink();
	   
	}

	@Then("^'Please fill the Building & Room No' message should display$")
	public void please_fill_the_Building_Room_No_message_should_display() throws Throwable {
		
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Building & Room No";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User selects 'Next' link without entereing  'Area Name'$")
	public void user_selects_Next_link_without_entereing_Area_Name() throws Throwable {
		
		driver.switchTo().alert().dismiss();
		pageBean.setBuildingAndRoomNo("B building, flat 405 ,Three Jewels Society");

		pageBean.clickNextPageLink();
	
	}

	@Then("^'Please fill the Area name' message should display$")
	public void please_fill_the_Area_name_message_should_display() throws Throwable {

		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Area name";
		Assert.assertEquals(expectedMessage, actualMessage);
		
	}

	@When("^User selects 'Next' link without selecting  'City'$")
	public void user_selects_Next_link_without_selecting_City() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setAreaName("Tilekarnagar, Kondhwa");

		pageBean.clickNextPageLink();
	}

	@Then("^'Please select city' message should display$")
	public void please_select_city_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please select city";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User selects 'Next' link without selecting  'State'$")
	public void user_selects_Next_link_without_selecting_State() throws Throwable {
	

		driver.switchTo().alert().dismiss();
		pageBean.setCity("Pune");

		pageBean.clickNextPageLink();
	}

	@Then("^'Please select state' message should display$")
	public void please_select_state_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please select state";
		Assert.assertEquals(expectedMessage, actualMessage);
		
		
	}

	@When("^User selects 'Next' link without selecting 'MemberShip Status'$")
	public void user_selects_Next_link_without_selecting_MemberShip_Status() throws Throwable {
	 
		driver.switchTo().alert().dismiss();
		pageBean.setState("Maharashtra");


		pageBean.clickNextPageLink();
		
	}

	@Then("^'Please Select MemeberShip status' message should display$")
	public void please_Select_MemeberShip_status_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please Select MemeberShip status";
		Assert.assertEquals(expectedMessage, actualMessage);
		
		
	}

	@When("^User selects 'Next' link after entering Valid set of information$")
	public void user_selects_Next_link_after_entering_Valid_set_of_information() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setMemberStatus("member");
		pageBean.clickNextPageLink();
	}

	@Then("^'Personal details are validated' message should display$")
	public void personal_details_are_validated_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Personal details are validated.";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	
	
	@Given("^User is on PaymentDetails page$")
	public void user_is_on_PaymentDetails_page() throws Throwable {
		driver1 = new ChromeDriver();
		driver1.manage().window().maximize();
		driver1.get("http://localhost:9098/Selenium/PaymentDetails.html");
		pageBean1= new PaymentsDetailsBean();
		PageFactory.initElements(driver1, pageBean1);
		
	}

	@When("^User selects 'Make Payment' button without entering 'CardHoldername'$")
	public void user_selects_Make_Payment_button_without_entering_CardHoldername() throws Throwable {
	    pageBean1.setPayment();
	}

	@Then("^'Please Fill CardHolder name' message should display$")
	public void please_Fill_CardHolder_name_message_should_display() throws Throwable {
		String actualMessage=driver1.switchTo().alert().getText();
		String expectedMessage="Please fill the Card holder name";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User selects 'Make Payment' button without entering 'Debit card Number'$")
	public void user_selects_Make_Payment_button_without_entering_Debit_card_Number() throws Throwable {
		driver1.switchTo().alert().dismiss();
		pageBean1.setCardHolderName("Nihal");
		 pageBean1.setPayment();
	}

	@Then("^'Please Fill Debitcard Number' message should display$")
	public void please_Fill_Debitcard_Number_message_should_display() throws Throwable {
		String actualMessage=driver1.switchTo().alert().getText();
		String expectedMessage="Please fill the Debit card Number";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User selects 'Make Payment' button without entering 'card Expiration month'$")
	public void user_selects_Make_Payment_button_without_entering_card_Expiration_month() throws Throwable {
		driver1.switchTo().alert().dismiss();
		pageBean1.setdebit("123456987456");
		pageBean1.setCvv("123");
		 pageBean1.setPayment();
	}

	@Then("^'Please fill expiration month message should display$")
	public void please_fill_expiration_month_message_should_display() throws Throwable {
		String actualMessage=driver1.switchTo().alert().getText();
		String expectedMessage="Please fill expiration month";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User selects 'Make Payment' button without entering 'card Expiration year'$")
	public void user_selects_Make_Payment_button_without_entering_card_Expiration_year() throws Throwable {
		driver1.switchTo().alert().dismiss();
		pageBean1.setMonth("10");
		pageBean1.setPayment();
	}

	@Then("^'Please fill expiration year' message should display$")
	public void please_fill_expiration_year_message_should_display() throws Throwable {
		String actualMessage=driver1.switchTo().alert().getText();
		String expectedMessage="Please fill the expiration year";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User selects 'Make Payment' button with entering valid details$")
	public void user_selects_Make_Payment_button_with_entering_valid_details() throws Throwable {
		driver1.switchTo().alert().dismiss();
		pageBean1.setYear("2025");
		pageBean1.setPayment();
	}

	@Then("^'Conference Room Booking Succesfully Done!!!' message should display$")
	public void conference_Room_Booking_Succesfully_Done_message_should_display() throws Throwable {
		String actualMessage=driver1.switchTo().alert().getText();
		String expectedMessage="Conference Room Booking successfully done!!!";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver1.close();
	}
	

}
