package com.capgemini.doctors.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;

//JUnit test cases for DAO class
class DoctorAppointmentDaoTest {
	DoctorAppointmentDao testdao=new DoctorAppointmentDao();
	DoctorAppointment test=new DoctorAppointment();

	@Test
	void testAddDoctorAppointmentDetails() {
		assertEquals(1,testdao.addDoctorAppointmentDetails(test));
		
	}

	@Test
	void testGetDoctorAppointmentDetails() {
		
		
	}

}
