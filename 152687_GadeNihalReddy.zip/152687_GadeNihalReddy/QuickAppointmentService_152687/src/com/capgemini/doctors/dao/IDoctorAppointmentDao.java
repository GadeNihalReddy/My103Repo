package com.capgemini.doctors.dao;

import com.capgemini.doctors.bean.DoctorAppointment;

//DAO Interface
public interface IDoctorAppointmentDao {
	int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment);
	DoctorAppointment getDoctorAppointmentDetails(int appointmentId);

}
