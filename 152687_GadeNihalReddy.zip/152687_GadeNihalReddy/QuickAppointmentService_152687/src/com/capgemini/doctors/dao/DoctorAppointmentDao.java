package com.capgemini.doctors.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.capgemini.doctors.bean.DoctorAppointment;

public class DoctorAppointmentDao implements IDoctorAppointmentDao {
	static Map<Integer,DoctorAppointment> appointments=new HashMap<Integer,DoctorAppointment>();
	
	
	//Adding Patients details to HashMap
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {
		
		appointments.put(doctorAppointment.getAppointmentId(), doctorAppointment);
		if(appointments.isEmpty()){
			return 0;
		}
		return 1;
	}
	
	//Displaying patient appointment details 
	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) {
		
		Iterator<Integer> it=appointments.keySet().iterator();
		while(it.hasNext()){
			int appId=it.next();
			if(appId==appointmentId)
			{
				return appointments.get(appId);
			}
		}
		return null;
	}

}
