package com.capgemini.doctors.service;

public class validateProblemName {
	// Validating the ProblemName
	public boolean isValidProblemName(String problemName) {

		if (problemName.equalsIgnoreCase("Heart")) {
			return true;

		} else if (problemName.equalsIgnoreCase("Gynecology")) {
			return true;

		} else if (problemName.equalsIgnoreCase("Diabetes")) {
			return true;

		} else if (problemName.equalsIgnoreCase("ENT")) {
			return true;

		} else if (problemName.equalsIgnoreCase("Bone")) {
			return true;
		} else if (problemName.equalsIgnoreCase("Dermatology")) {
			return true;
		} else {
			System.out.println("Problem Name Not matched");
			return false;
		}

	}
	public boolean isValidPhoneNumber(String phoneNumber)
	{
		if(phoneNumber.length()==10)
		{
			return true;
		}
		else
			System.out.println("Enter 10 digit mobile number");
		return false;
		
	}

}
