package com.capgemini.doctors.service;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;

public class DoctorAppointmentService implements IDoctorAppointmentService {
	DoctorAppointmentDao dao=new DoctorAppointmentDao();

	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {
		
		return dao.addDoctorAppointmentDetails(doctorAppointment);
	}

	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) {
		
		return dao.getDoctorAppointmentDetails(appointmentId);
	}

}
