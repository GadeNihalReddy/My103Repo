package com.capg.streamapi;

import java.util.List;
import java.util.stream.Stream;

public class EmployeeService {
	double sum=0;

	public void salary(List<Employee>obj)
	{
		Stream<Employee> s =obj.stream();
		s.forEach(sa-> sum +=sa.getSalary());
		System.out.println("Total Salary :"+sum);
	}
}
