package com.capg.streamapi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Springcls1 {
	public static int[] ar;
	static int sum=0;
	static int prod=1;
	static int ans;

	public static void main(String[] args) {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		try {
			System.out.println("Enter array size");
			int k=Integer.parseInt(br.readLine());
			if(k%2!=0)
			{
			ar=new int[k];
			System.out.println("Enter elements into array");
			for(int i=0;i<ar.length;i++)
			{
				ar[i]=Integer.parseInt(br.readLine());
				if(i<(ar.length/2))
						sum=sum+ar[i];
				else if(i==ar.length/2)
					continue;
				else
					prod=prod*ar[i];
			}
//			
//			for(int j=0;j<ar.length/2;j++)
//			{
//				sum=sum+ar[j];
//				
//				
//			}
//			for(int l=ar.length/2+1;l<ar.length;l++)
//			{
//				 prod = prod*ar[l];
//				 
//			}
			ans=sum+prod;
			System.out.println(ans);
			
			}
			else
			{
				System.out.println("Enter odd no.");
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
