package com.capg.streamapi;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Lab11_6EmployeeRepository {

	public static void main(String[] args) {
		EmployeeService er=new EmployeeService();
		List<Employee> list =new ArrayList<>();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no.of employees");
		int num=sc.nextInt();
		for(int i=0;i<num;i++)
		{
			Employee obj =new Employee();
			System.out.println("enter employee id");
			int employeeID=sc.nextInt();
			sc.nextLine();
			System.out.println("Enter first name");
			String firstName=sc.nextLine();
			System.out.println("Enter LastName");
			String lastName=sc.nextLine();
			
			System.out.println("Enter salary");
			double salary =sc.nextDouble();
			
			obj.setSalary(salary);
			list.add(obj);
		}
		er.salary(list);
			
			
			
		}

	}


