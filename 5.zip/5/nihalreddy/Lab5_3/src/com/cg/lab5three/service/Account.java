package com.cg.lab5three.service;

public abstract class Account {
	private long accNum;
	protected double balance;
	Person p;
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getP() {
		return p;
	}
	public void setP(Person p) {
		this.p = p;
	}
	public abstract double Deposite(double amount);
	public abstract double withdraw(double amount);
	

}
