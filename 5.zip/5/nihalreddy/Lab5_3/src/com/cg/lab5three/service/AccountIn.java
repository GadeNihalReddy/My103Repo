package com.cg.lab5three.service;

public class AccountIn extends Account{

	@Override
	public double Deposite(double amount) {
		return balance+=amount;
		
	}

	@Override
	public double withdraw(double amount) {
		return balance-=amount;
		
	}
	

}
