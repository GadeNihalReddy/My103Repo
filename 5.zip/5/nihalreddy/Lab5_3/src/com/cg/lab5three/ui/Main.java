package com.cg.lab5three.ui;

import java.util.Random;
import java.util.Scanner;

import com.cg.lab5three.service.Account;
import com.cg.lab5three.service.AccountIn;
import com.cg.lab5three.service.Person;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Random ran=new Random();
		System.out.println("Enter AccountHolder name");
		String personName=sc.next();
		System.out.println("Enter Person's Age ");
		float personAge=sc.nextFloat();
		System.out.println("Enter the Balance");
		double balance=sc.nextDouble();
		Account a=new AccountIn();
		System.out.println("Enter amount to deposite");
		double k=a.Deposite(sc.nextDouble());
		
		
		Person p=new Person();
		p.setName(personName);
		p.setAge(personAge);
		
		
		a.setAccNum(ran.nextLong());
		a.setBalance(balance);
		a.setP(p);
		a.Deposite(k);
		String ac1=p.getName();
		
		System.out.println("Account Number is "+a.getAccNum());
		System.out.println("Balance is "+a.getBalance());
		System.out.println("Account Holder Name is "+a.getP().getName());
		System.out.println("Account Holder Age is "+a.getP().getAge());
	}

}
