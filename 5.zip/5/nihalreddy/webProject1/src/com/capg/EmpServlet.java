package com.capg;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/EmpServlet")
public class EmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public EmpServlet() {
        super();
       
    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Employee e=new Employee();
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.println("Hi");
		String eName=request.getParameter("eName");
		int eId=Integer.parseInt(request.getParameter("eId"));
		double eSalary=Double.parseDouble(request.getParameter("eSalary"));
		
		
		e.seteId(eId);
		e.seteName(eName);
		e.seteSalary(eSalary);
		
		request.setAttribute("e1", e);
		//HttpSession session=request.getSession();
		//session.setAttribute("e1", e);
		
		RequestDispatcher rd=request.getRequestDispatcher("/SecondServlet");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
}
