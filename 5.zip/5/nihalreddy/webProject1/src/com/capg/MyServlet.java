package com.capg;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
//		response.setContentType("f");
		out.print("<body bgcolor=skyblue>this is html </br>");
		out.print("</br>Welcome........</br>");
		out.print("heloooooooooo");
		out.println(request.getRemotePort()+"</br>"+request.getLocalName());
		out.println(request.getLocalPort()+request.getServerName());
		String uname=request.getParameter("uname");
		String pwd=request.getParameter("pwd");
		String gender=request.getParameter("gender");
		
		
		out.println("UserName"+uname);
		out.println("password"+pwd);
		out.println("gender"+gender);
		Enumeration<String> en=request.getParameterNames();
		while(en.hasMoreElements())
		{
			String param =en.nextElement();
			out.println(request.getParameter(param));
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
