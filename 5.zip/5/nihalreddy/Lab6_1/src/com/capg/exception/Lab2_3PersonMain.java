package com.capg.exception;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lab2_3PersonMain {

	public static void main(String[] args) {
		
		
		Lab2_3Person P=new Lab2_3Person();
		System.out.println("Enter first name, lastname and Gender");
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		try {
			String FirstName= br.readLine();
			String LastName = br.readLine();
			char Gender = (char)br.read();
			if(FirstName.isEmpty()==true||LastName.isEmpty()==true)
			{
				try {
					throw new NoNameException("First Name Or LastName must be written");
				}catch (NoNameException e) {
					e.printStackTrace();
				}
			}
			P.setFirstName(FirstName);
			P.setLastName(LastName);
			P.setGender(Gender);
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
		System.out.println("Person Details");
		
		System.out.println("___________________");
		System.out.println();
		System.out.println("FirstName:"+P.getFirstName());
		System.out.println("LastName:"+P.getLastName());
		System.out.println("Gender:"+P.getGender());
	
		

	}

}
