package com.capg.exception;

public class Lab2_3Person {
	private String FirstName;
	private String LastName;
	private char Gender;
	

	public String getFirstName() {
		return FirstName;
	}


	public void setFirstName(String FirstName) {
		this.FirstName = FirstName;
	}


	public String getLastName() {
		return LastName;
	}


	public void setLastName(String LastName) {
		this.LastName = LastName;
	}


	public char getGender() {
		return Gender;
	}


	public void setGender(char Gender) {
		this.Gender = Gender;
	}

	
	public Lab2_3Person() {
		super();
	}


	public Lab2_3Person(String FirstName, String LastName, char Gender) {
		super();
		this.FirstName = FirstName;
		this.LastName = LastName;
		this.Gender = Gender;
	}
	

	
}
