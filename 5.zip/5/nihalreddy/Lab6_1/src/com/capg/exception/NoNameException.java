package com.capg.exception;

public class NoNameException extends Exception{

	private String string;

	public NoNameException(String string) {
		this.string=string;
	}

	
	@Override
	public String toString() {
		return "NoNameException [string=" + string + "]";
	}


	private static final long serialVersionUID = 1L;

}
