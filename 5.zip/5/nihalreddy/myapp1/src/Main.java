
public class Main {

	public static void main(String[] args) {
		//CalculatorInterface ci= ()->{System.out.println(5);return 5;};
		CalculatorInterface ci =(s)->{
			System.out.println("with param n value");
			return s.length();
		};
		
		int n= ci.fun("Nihal Reddy");
		System.out.println(n);
	}

}
