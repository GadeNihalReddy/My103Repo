//9.2: Create a file named as �numbers.txt� which should contain numbers from 0 to 10 delimited by comma. Write a program to read data from numbers.txt using Scanner class API and display only even numbers in the console.

package com.capgemini.lesson9;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class EvenNumber 
{
	public static void main(String[] args) throws FileNotFoundException 
	{
		String file = "D:\\Labwork 153062 YashGeel\\Labwork 153062 Yash Geel\\src\\com\\capgemini\\lesson9\\Number.txt";
		File file1 = new File(file);
		
		Scanner sc =new Scanner(file1);
		String str = sc.nextLine();
		System.out.println("elements in the file are as follows.");
		System.out.println(str);
		System.out.println("evens numbers are");
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)==',')
			{
				String st1 = str.substring(0, i);
				String temp1 = "";
				temp1 = temp1 + st1;
				int n1 = Integer.parseInt(temp1);
				if(n1%2==0)
				{
					System.out.println(n1);
				}
				
				
				for(int k = i+1 ; k<str.length();k++)
				{
					if(str.charAt(k)==',')
					{
						String st = str.substring(i+1, k);
						//System.out.println(st);
						String temp = "";
						temp = temp + st;
						int n = Integer.parseInt(temp);
						if(n%2==0)
						{
							System.out.println(n);
						}
						i = k ;
					}
				}
			}
			
		}
		
		int i = str.lastIndexOf(',');
		String temp2 = str.substring(i+1, str.length());
		String temp3 = "";
		temp3 = temp3 + temp2;
		int n = Integer.parseInt(temp3);
		if(n%2==0)
		{
			System.out.println(n);
		}
		
		
		
	}
}
