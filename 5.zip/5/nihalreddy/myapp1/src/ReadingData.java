import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ReadingData {

	public static void main(String[] args) {
		
		
		BufferedReader br =new BufferedReader(new InputStreamReader(System.in));
		
		try {
			//char c=(char) br.read();
			System.out.println("Enter your id");
			String data= br.readLine();
			
			System.out.println("Enter your Name");
			String Name=br.readLine();
			System.out.println("Enetr your fee");
			String fee=br.readLine();
			
			Integer i=new Integer(fee);
			int j=Integer.parseInt(fee);
			int total=i+100;
			System.out.println(data+" "+Name+" "+total);
			System.out.println(args[0]+" "+args[1]);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
