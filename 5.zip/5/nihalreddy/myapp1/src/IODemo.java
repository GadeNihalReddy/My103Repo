import java.io.IOException;

public class IODemo {
	
	

	public static void main(String[] args) {
		
		char c ;
		StringBuffer sb= new StringBuffer();
		
		try {
			while((c=(char)System.in.read())!='\n')
				{
						//System.out.print(c);
				sb.append(c);
				}
			String s= new String(sb);
			System.out.println("my data is " +s);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
