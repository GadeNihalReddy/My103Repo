import java.io.FileInputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

public class PDemo {

	public static void main(String[] args) {
		
		
		FileInputStream fis=null;
		
		
		Properties p=new Properties();
		try {
			
			fis=new FileInputStream("abc.properties");
			p.load(fis);
			
			System.out.println(p.getProperty("mobileNumber"));
			p.setProperty("Username","scott");
			Enumeration en= p.propertyNames();
			
			while (en.hasMoreElements()) {
				String key=(String)en.nextElement();
				System.out.println(p.getProperty(key));
				
			}
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
