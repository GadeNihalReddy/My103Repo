import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

public class Lab7 {
	
	public static int getMethod(int a[]) {
		System.out.println("Enter the elements");
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		//for(int i=0;i<a.length;i++)
		String res=Arrays.toString(a);
		System.out.print(res);
		Iterator<String[]> it=res.iterator<String[]>();
		//System.out.println(res);
		/*for(int i=0;i<;i++)
		{
			System.out.println(res);
		}*/
		return 0;
		
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no.of elements in array");
		getMethod(new int[sc.nextInt()]);
	}

}
