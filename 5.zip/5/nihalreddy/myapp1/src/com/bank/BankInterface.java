package com.bank;

public interface BankInterface {
	
	void deposite();
	void withdraw();
	

}
