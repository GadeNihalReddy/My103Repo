package com.bank;

public abstract class Bank1 implements BankInterface {

	@Override
	public void deposite() {
		// TODO Auto-generated method stub
System.out.println("Deposited......");
	}


	

}
