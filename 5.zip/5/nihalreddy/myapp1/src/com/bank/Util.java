package com.bank;

public class Util {
	
	public BankInterface get() {
		BankInterface b=new Bank2();
		return b;
	}

}
