package com.bank;

public class Bank2 extends Bank1 {

	@Override
	public void withdraw() {
		// TODO Auto-generated method stub
        System.out.println("Money withdrawn");
	}

}
