package com.bank;

import java.util.Scanner;

public class User {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Welcome to CAPG Bank");
		
		System.out.println("1.Deposite  2.Withdraw  3. Exit");
		Scanner sc= new Scanner(System.in);
		/* for(int i = 0; i < n; i++)
        {
            a[i] = s.nextInt();*/
		int choice=sc.nextInt();
		Util t=new Util();
		//BankInterface bi=Util.get();
	BankInterface bi =	t.get();
		
		switch (choice) {
		case 1:
			bi.deposite();
			break;
		case 2:
			bi.withdraw();
			break;
		default:
			System.exit(0);
			break;
		}

	}

}
