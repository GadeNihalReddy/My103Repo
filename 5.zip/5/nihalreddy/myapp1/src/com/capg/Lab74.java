package com.capg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class Lab74 {
	

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] ar=new int[n];
		
		for(int i=0;i<n;i++)
		{
			ar[i]=sc.nextInt();
		}
        Map<Integer,Integer> m1=new HashMap<Integer,Integer>();
        m1=getSquares(ar);
        
    	System.out.println(m1);
	}
	public static Map getSquares(int arr[])
	{
		int n=arr.length;
		int[] sqr=new int[n];
		for(int i=0;i<n;i++)
		{
			sqr[i]=arr[i]*arr[i];
		}
		Map<Integer,Integer> m=new HashMap<Integer,Integer>();
		for(int i=0;i<n;i++)
		{
			m.put(arr[i],sqr[i]);
		}
		
	
		return m;
	}

}
