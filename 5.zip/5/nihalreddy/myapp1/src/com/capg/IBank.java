package com.capg;

public interface IBank {
	
    public static final int PI=3;
    
	public abstract void deposite();
	void withdraw();
	void display();

}
