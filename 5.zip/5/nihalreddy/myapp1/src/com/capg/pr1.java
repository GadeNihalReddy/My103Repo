package com.capg;

public class pr1 extends Demo {
	
	public static void main(String[] args) {
		Demo t=new Demo(10,"Nihal",1234);
		Demo t1=new Demo(11,"Rithish");
		System.out.println(t1.toString());
		System.out.println(t.toString());
	}

}
