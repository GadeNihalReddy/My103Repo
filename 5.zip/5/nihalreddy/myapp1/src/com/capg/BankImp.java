package com.capg;

public class BankImp implements IBank {

	@Override
	public void deposite() {
		// TODO Auto-generated method stub
		System.out.println("Deposited...");
	}
    public static void main(String[] args)
    {
    	BankImp p1=new BankImp();
    	p1.deposite();
    	p1.display();
    	p1.withdraw();
    }
	@Override
	public void withdraw() {
		System.out.println("withdrawn");
		// TODO Auto-generated method stub
		
	}
	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("displayed the details");
		
	}
	
    
}
