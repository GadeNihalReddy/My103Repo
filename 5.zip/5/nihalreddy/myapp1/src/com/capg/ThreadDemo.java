package com.capg;

public class ThreadDemo extends Thread {
	
	@Override
	public void run() {
		
		super.run();
		System.out.println("run() is called");
		for(int i=0;i<5;i++)
		{
			System.out.println("Child thread"+i);
		}
	}

	public static void main(String[] args) throws InterruptedException {
		
		
		
		
		ThreadDemo td = new ThreadDemo();
		
		
		
		Thread.sleep(3000);
		td.start();
		
		for(int i=0;i<5;i++)
		{
			System.out.println("Main thread"+i);
		}

	}

}
