package com.capg;

public class Demo {
	
     int id;
     String name;
     int salary;
	public Demo(int id, String name, int salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	public Demo(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Demo() {
	}
	@Override
	public String toString() {
		return "Demo [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
     
		
	
	

}
