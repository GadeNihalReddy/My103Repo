package com.capg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Lab7_1 {
	
	public static int getSorted(int arr[])
	{
		int n=arr.length;
		String[] k= new String[n];
		for(int i=0;i<n;i++)
		{
			k[i]=String.valueOf(arr[i]);
			StringBuilder s=new StringBuilder();
			s.append(k[i]);
			s=s.reverse();
			k[i]=s.toString();
		}
	ArrayList<Integer>li=new ArrayList<Integer>();
	for(int i=0;i<n;i++)
	{
		int x= Integer.parseInt(k[i]);
		li.add(x);
	}
	Collections.sort(li);
	System.out.println(li);
	return 0;
	}


	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int l=sc.nextInt();
		int[] ar=new int[l];
		for(int i=0;i<l;i++)
		{
			ar[i]=sc.nextInt();
			
		}
		getSorted(ar);
		
}
}
