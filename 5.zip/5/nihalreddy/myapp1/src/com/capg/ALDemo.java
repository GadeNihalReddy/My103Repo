package com.capg;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class ALDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Vector<Integer> list=new Vector<Integer>();
		
		
		list.add(new Integer(4));
		list.add(9);
		list.add(8);
		list.add(5);
		
		Iterator it= list.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		//Enumeration<Integer> en= list.elements();
		
		
		System.out.println(list);
		for (int x : list) {
			System.out.println(x);
		}
		

	}

}
