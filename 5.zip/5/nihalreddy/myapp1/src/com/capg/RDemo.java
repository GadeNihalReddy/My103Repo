package com.capg;

public class RDemo implements Runnable{

	@Override
	public void run() {
	
		
		System.out.println("this is run()...");
		
	}
      public static void main(String[] args) {
    	  System.out.println("This is main()..");
    	  RDemo r=new RDemo();
    	  
    	  Thread t=new Thread(r,"hello");
    	  t.setPriority(10);
    	  System.out.println(t.isAlive());
    	  t.setPriority(Thread.MAX_PRIORITY-1);
    	  System.out.println(t.getPriority());
    	  t.start();
    	  
		
	}
}
