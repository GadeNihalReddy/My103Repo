package com.capg;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HMDemo {

	public static void main(String[] args) {
		
		Map<Integer,String> m=new HashMap<Integer,String>();
		
		//Integer i1=new Integer(113);
		//Integer i2=new Integer(11);
		m.put(1,"Nihal");
		m.put(null, "bala");
		m.put(162, "rithu");
		m.put(413, "jani");
		System.out.println(m);
		Set st=m.keySet();
		Iterator<Integer> it=st.iterator();
		while(it.hasNext()) {
			int k=it.next();
			System.out.println(k);
			System.out.println(m.get(k));
		}

	}

}
