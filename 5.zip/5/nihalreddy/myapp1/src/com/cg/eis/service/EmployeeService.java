package com.cg.eis.service;

public interface EmployeeService {
	
	void getDetails();
	void getInsuranceScheme();
	void displayDetails();
	

}
