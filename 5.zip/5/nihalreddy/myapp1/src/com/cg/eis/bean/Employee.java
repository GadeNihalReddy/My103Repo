package com.cg.eis.bean;

public class Employee {
	
	int id;
	String name;
	double Salary;
	String desg;
	
	public void insuranceScheme(String desg,int id) {
		if(desg=="clerk" && Salary<5000)
		{
			System.out.println("No Scheme for Clerks position");
		}
		else if(desg=="Manager" && Salary>=40000)
		{
			System.out.println("Manager has Schemme A Insurance policy");
		}
		else if(desg=="Programmer" && (Salary>=20000 && Salary<40000))
		{
			System.out.println("Programmer has Schemme B Insurance policy");
		}
		else if(desg=="System Associate" && (Salary>5000 && Salary<20000) )
		{
			System.out.println("System Associate has Schemme A Insurance policy");
		}
		else
		{
			System.out.println("Invalid Designation");
		}
		
		
	}

}
