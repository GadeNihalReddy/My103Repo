package com.cg.eis.service;

public class Implementation implements EmployeeService {

	@Override
	public void getDetails() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getInsuranceScheme() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayDetails() {
		// TODO Auto-generated method stub
		
	}
	

}
