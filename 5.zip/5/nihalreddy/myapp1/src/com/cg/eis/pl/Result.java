package com.cg.eis.pl;

public class Result {

	
	public static void main(String[] args) {
		
	}

}
