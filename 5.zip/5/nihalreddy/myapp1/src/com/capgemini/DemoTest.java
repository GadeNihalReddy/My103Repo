package com.capgemini;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

public class DemoTest {

	@Test
	public void testGetData() {
		//fail("Not yet implemented");
		assertEquals("Raju",Demo.getData());
		
	}

	@Test
	@Ignore
	public void testGetNum() {
		//fail("Not yet implemented");
	}

}
