package com.capgemini;

public class Demo {
	
	public static String getData()
	{
		return "Raju";
	}
	public static int getNum()
	{
		return 99;
	}

}
