//4.2

package com.capgem.cop;

public class CurrentAccount extends Account
{
int overdraftLimit=500;
	
	@Override
	public boolean withdraw(double balance) 
	{
		if((super.balance-balance)>-500)
		{
			super.balance = super.balance - balance;
			return true;
		}	
		return false;
	}

	public CurrentAccount(String firstName, String lastName, int age,
			double balance) {
		super(firstName, lastName, age, balance);
		
	}
	
	
	
}
