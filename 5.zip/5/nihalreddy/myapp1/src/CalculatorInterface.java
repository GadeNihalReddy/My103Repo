

@FunctionalInterface
public interface CalculatorInterface {
	
		int fun(String s);
		
}
