//6.2: Validate the age of a person in Lab assignment 4.2 and display proper message by using user defined exception. Age of a person should be above 15.

package com.capg.lab6_2;

import java.util.Scanner;

class myException1 extends Exception {
	public String getMessage() {
		return "Please enter age above 15";
	}

}

public class Lab6_2AgeException {
	public static void main(String[] args) throws myException1 {
		int age;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the age");
		age = sc.nextInt();
		int age1 = checkAge(age);
		System.out.println("age is : " + age1);

	}

	public static int checkAge(int age) throws myException1 {
		if (age <= 15) {
			try {
				throw new myException1();

			} catch (myException1 e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			return age;
		}
		return age;
	}
}