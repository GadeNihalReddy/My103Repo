package com.capg;

public class SavingAccount extends Account {

	final double balance = 500;

	@Override
	public boolean withdraw(double balance) {

		if ((super.balance - balance) > 500) {
			super.balance = super.balance - balance;
			return true;
		} else
			return false;
	}

	public SavingAccount(String firstName, String lastName, int age, double balance) {

		super(firstName, lastName, age, balance);
	}

}
