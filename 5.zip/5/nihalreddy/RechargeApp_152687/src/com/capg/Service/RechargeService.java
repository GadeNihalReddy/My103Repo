package com.capg.Service;

import java.util.Iterator;
import java.util.List;

import com.capg.bean.RechargeDetails;
import com.capg.dao.RechargeDAO;

public class RechargeService implements IRechargeService {
	
	RechargeDAO dao=new RechargeDAO();
	
		public boolean addRechargeDetails(RechargeDetails recharge)
		{
			
			return dao.addRechargeDetails(recharge);
		}
		public RechargeDetails displayDetails(long tid)
		{
		return dao.displayDetails(tid);
		}
		@Override
		public boolean updateDetails(RechargeDetails update) {
			
			return dao.updateDetails(update);
		}
		public boolean removeDetails(long tid) {
			
			return dao.removeDetails(tid);
		}
		public List displayAll() {
			
			return dao.displayAll();
		}
		
		
		
		
		
		
		
		
		
		
}
