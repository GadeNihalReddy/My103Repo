package com.capg.Service;

import java.util.List;

import com.capg.bean.RechargeDetails;

public interface IRechargeService {
	
	public boolean addRechargeDetails(RechargeDetails recharge);
	public RechargeDetails displayDetails(long tid);
	public boolean updateDetails(RechargeDetails update);
	public boolean removeDetails(long tid);
	public List displayAll();
}
