package com.capg.Service;

public class RechargeDataValidate {
	
	public boolean validatedthOperator(String dthOperator)
	{
		if(dthOperator.equalsIgnoreCase("Airtel") ||dthOperator.equalsIgnoreCase("DishTv") ||dthOperator.equalsIgnoreCase("Reliance") ||dthOperator.equalsIgnoreCase("TATA"))
		return true;
		else {
			System.out.println("Enter valid Operator");
			return false;
		}
	}
	public boolean validateConsumerNo(String consumerNo)
	{
		if(consumerNo.length()==10)
		return true;
		else return false;
	}
	
	public boolean validatePlan(String rechargePlan)
	{
		if(rechargePlan.equalsIgnoreCase("Monthly")||rechargePlan.equalsIgnoreCase("Quarterly")||rechargePlan.equalsIgnoreCase("HalfYearly")||rechargePlan.equalsIgnoreCase("Annual"))
		return true;
		else {
			System.out.println("Enter valid Plan");
			return false;
		}
	}
	
	public boolean validateAmount(String amount) 
	{
		int am1=Integer.parseInt(amount);
		if(am1>=100 && am1<=9999)
		{
			return true;
		}
		else {
			System.out.println("Enter valid amount");
			return false;
		}
		
	}
}
