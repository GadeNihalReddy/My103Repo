package com.capg.bean;

public class RechargeDetails {
		
	private String dthOperator;
	private int consumerNo;
	private String rechargePlan;
	private int amount;
	private long tid;
	public String getDthOperator() {
		return dthOperator;
	}
	public void setDthOperator(String dthOperator) {
		this.dthOperator = dthOperator;
	}
	public int getConsumerNo() {
		return consumerNo;
	}
	public void setConsumerNo(int consumerNo) {
		this.consumerNo = consumerNo;
	}
	public String getRechargePlan() {
		return rechargePlan;
	}
	public void setRechargePlan(String rechargePlan) {
		this.rechargePlan = rechargePlan;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public long getTid() {
		return tid;
	}
	public void setTid(long tid) {
		this.tid = tid;
	}
	@Override
	public String toString() {
		return "RechargeDetails [dthOperator=" + dthOperator + ", consumerNo=" + consumerNo + ", rechargePlan="
				+ rechargePlan + ", amount=" + amount + ", tid=" + tid + "]"+"\n";
	}
	
	
	
}
