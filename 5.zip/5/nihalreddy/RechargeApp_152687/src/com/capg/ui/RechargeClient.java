package com.capg.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.List;

import com.capg.Service.RechargeDataValidate;
import com.capg.Service.RechargeService;
import com.capg.bean.RechargeDetails;
import com.capg.exception.NoTransactionFoundException;

public class RechargeClient {
	static boolean b=false;
	static long tid=0;
	public static void addrcDetails() {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		RechargeDataValidate validate =new RechargeDataValidate();
		RechargeService service=new RechargeService();
           try {
			System.out.println("Enter Operator(Airtel/DishTv/Reliance/TATA)");
			String dthOperator =br.readLine();
			System.out.println("Enter ConsumerNo");
			String consumerNo=br.readLine();
			System.out.println("Enter RechargePlan(Monthly/Quarterly/HalfYearly/Annual)");
			String rechargePlan=br.readLine();
			System.out.println("Enter Amount(100 to 9999)");
			String amount=br.readLine();
			tid=(long)(Math.random()*1234 + 9999);
			System.out.println(tid);
			RechargeDetails recharge =new RechargeDetails();
			recharge.setDthOperator(dthOperator);
			recharge.setConsumerNo(Integer.parseInt(consumerNo));
			recharge.setAmount(Integer.parseInt(amount));
			recharge.setRechargePlan(rechargePlan);
			recharge.setTid(tid);
			boolean isValidOperator =validate.validatedthOperator(dthOperator);
			boolean isValidConsumerNo= validate.validateConsumerNo(consumerNo);
			boolean isValidPlan =validate.validatePlan(rechargePlan);
			boolean isValidAmount=validate.validateAmount(amount);
		if(isValidOperator && isValidConsumerNo && isValidPlan && isValidAmount)
			{
				b= service.addRechargeDetails(recharge);
				System.out.println("adding");
			}
			else
			{
				System.out.println("Enter Valid Details");
			}
           } catch (IOException e) {
   			e.printStackTrace();
	}
           
  		 if(b)
  		 {
  			 System.out.println("Recharge Succesfullnd Tid is"+tid);
  		 }
  		 else {
  			 try {
  				 throw new NoTransactionFoundException();
  			 }catch (NoTransactionFoundException e)
  			 {
  				 System.err.println("Transaction Failure");
  			 }
  		 }
	}
	public static void displayDetails() {
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		RechargeService service=new RechargeService();
		try {
			System.out.println("Enter Transaction Id");
			tid=Long.parseLong(br.readLine());
			if(service.displayDetails(tid)==null)
			{
				System.out.println("Record Not Found");
			}
			else 
				
			System.out.println(service.displayDetails(tid));
			
			
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
    public static void updateDetails() {
    	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		RechargeDataValidate validate =new RechargeDataValidate();
		RechargeService service=new RechargeService();
		
		
		try {
			System.out.println("Enter Transaction Id");
			tid=Long.parseLong(br.readLine());
			System.out.println("Enter Operator(Airtel/DishTv/Reliance/TATA)");
			String dthOperator =br.readLine();
			System.out.println("Enter ConsumerNo");
			String consumerNo=br.readLine();
			System.out.println("Enter RechargePlan(Monthly/Quarterly/HalfYearly/Annual)");
			String rechargePlan=br.readLine();
			System.out.println("Enter Amount(100 to 9999)");
			String amount=br.readLine();
			RechargeDetails update =new RechargeDetails();
			update.setDthOperator(dthOperator);
			update.setConsumerNo(Integer.parseInt(consumerNo));
			update.setAmount(Integer.parseInt(amount));
			update.setRechargePlan(rechargePlan);
			update.setTid(tid);
			boolean isValidOperator =validate.validatedthOperator(dthOperator);
			boolean isValidConsumerNo= validate.validateConsumerNo(consumerNo);
			boolean isValidPlan =validate.validatePlan(rechargePlan);
			boolean isValidAmount=validate.validateAmount(amount);
		    if(isValidOperator && isValidConsumerNo && isValidPlan && isValidAmount)
			{
				b= service.updateDetails(update);
				System.out.println("updated");
			}
			else
			{
				System.out.println("Enter Valid Details");
			}
			
		} catch (NumberFormatException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		if(b)
 		 {
 			 System.out.println("Updated Succesfully and Tid is"+tid);
 		 }
 		 else {
 			 try {
 				 throw new NoTransactionFoundException();
 			 }catch (NoTransactionFoundException e)
 			 {
 				 System.err.println("Updation Failed");
 			 }
 		 }
		
	}
    
    public static void removeDetails() {
		
    	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    	RechargeService service=new RechargeService();
		try {
			System.out.println("Enter Transaction Id");
			tid=Long.parseLong(br.readLine());
			b=service.removeDetails(tid);
			
			
		} catch (NumberFormatException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		if(b)
		 {
			 System.out.println("Removed Succesfully ");
		 }
		 else {
			 try {
				 throw new NoTransactionFoundException();
			 }catch (NoTransactionFoundException e)
			 {
				 System.err.println("Deletion Failed");
			 }
		 }
	}
    public static void displayAll() {
    	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		RechargeService service=new RechargeService();
		System.out.println(service.displayAll());
		
	}
	
	public static void main(String[] args) {
		int choice=0;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		do {
		System.out.println("1.Make a Recharge \n2.Display Recharge Details\n3.Update Details\n4.Remove Details\n5.Exit");
		System.out.println("Enter choice");
		try {
			choice=Integer.parseInt(br.readLine());
			switch (choice) {
			case 1:
				addrcDetails();
				break;
			case 2:
				displayDetails();
				break;
			case 3:
				updateDetails();
				break;
			case 4:
				removeDetails();
				break;
			case 5:
				displayAll();
				break;
			case 6:
				System.out.println("Thank you");
				System.exit(0);
				break;
			default:
				System.out.println("Enter valid choice");
				break;
			}
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		}while(choice!=6);
	}
	
	

}
