package com.capg.test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Test;

import com.capg.Service.RechargeDataValidate;
import com.capg.bean.RechargeDetails;

public class RechargeDataValidateTest {
	
	RechargeDataValidate service= new RechargeDataValidate();
	
	@Test
	public void testValidatedthOperator() {
		
	assertTrue(service.validatedthOperator("Airtel"));
		
	}

	@Test
	public void testValidateConsumerNo() {
		
		assertEquals(true, service.validateConsumerNo("1234567890"));
	}

	@Test
	public void testValidatePlan() {
		
		assertEquals(true,service.validatePlan("Monthly"));
		
	}

	@Test
	public void testValidateAmount() {
		
		assertEquals(false, service.validateAmount("0"));
	}

}
