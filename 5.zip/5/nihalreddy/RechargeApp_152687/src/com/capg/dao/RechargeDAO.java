package com.capg.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capg.bean.RechargeDetails;

public class RechargeDAO implements IRechargeDAO {
	boolean flag=false;
    static	List<RechargeDetails> list= new ArrayList<RechargeDetails>();
	public boolean addRechargeDetails(RechargeDetails recharge)
	{
		
		flag = list.add(recharge);
		System.out.println(flag);
		System.out.println(list);
		return flag;
	}
	public RechargeDetails displayDetails(long tid)
	{
			
			Iterator<RechargeDetails> it =list.iterator();
			//System.out.println(it.hasNext()+" isTrue");
			while (it.hasNext()) {
			long t =0;
			RechargeDetails rec =  it.next();
			t =	rec.getTid();
			if(tid == t) {
				return rec;
					
			}
//			else {
//				System.out.println("Invalid Tid");
				
			//}
			}
			return null;
	}

	@Override
	public boolean updateDetails(RechargeDetails update) {
		Iterator<RechargeDetails> it =list.iterator();
		while (it.hasNext()) {
			RechargeDetails upd = it.next();
			
			if(update.getTid() == upd.getTid()) {
				//System.out.println(list);
				upd.setDthOperator(update.getDthOperator());
				upd.setConsumerNo(update.getConsumerNo());
				upd.setAmount(update.getAmount());
				upd.setRechargePlan(update.getRechargePlan());	
				flag=true;
			}
	}
		return flag;
	}

	public boolean removeDetails(long tid) {
		Iterator<RechargeDetails> it =list.iterator();
		//System.out.println(it.hasNext()+" isTrue");
		while (it.hasNext()) {
		long t =0;
		RechargeDetails rec =  it.next();
		
		t =	rec.getTid();
		if(tid == t) {
			
		flag=list.remove(rec);
		return flag;
		
	}
}return flag;
	}
	public List displayAll() {
		Iterator<RechargeDetails> it =list.iterator();
		
		while (it.hasNext()) {
			
			return list;
		}
		return null;
	}
}
	

