
public class Employee {
	public static int id;
	public static int salary;
	

	public Employee(int id, int salary) {
		super();
		this.id = id;
		this.salary = salary;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getSalary() {
		return salary;
	}


	public void setSalary(int salary) {
		this.salary = salary;
	}


	public static void main(String[] args) {
		
		System.out.println("id is" +id+ "and salary is"+salary);

	}

}
