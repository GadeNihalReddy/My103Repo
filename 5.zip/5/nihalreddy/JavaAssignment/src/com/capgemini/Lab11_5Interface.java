package com.capgemini;

public interface Lab11_5Interface {
	
	public abstract void fact(int n);

}
