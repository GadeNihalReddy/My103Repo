package com.capgemini;

import java.util.Queue;

public class BillerThread implements Runnable {
	private Queue sharedQ;
	private final int MAX_SIZE;
	

	public BillerThread(Queue sharedQ, int mAX_SIZE) {
		super();
		this.sharedQ = sharedQ;
		MAX_SIZE = mAX_SIZE;
	}

	@Override
	public void run() {
		while(true) {
			synchronized(sharedQ) {
				while(sharedQ.isEmpty()) {
					try
					{
						System.out.println("Billing completed");
						sharedQ.wait();
					}
					catch(Exception e) {
						System.out.println("error:"+e);
					}
				}
				System.out.println("Product:"+sharedQ.remove());
				sharedQ.notify();
			}
		}
	}

}
