package com.capgemini;

import java.util.Scanner;

public class Lab3_2 {
	static String str;
	static int k;
	public boolean stringCheck(String str)
	{
		
		for(int i=1;i<str.length();i++)
		{
			for(int j=i+1;j<str.length();j++)
				if((int)str.charAt(i-1)>(int)str.charAt(i))
					k=1;	
		}
		if(k==0)
		{
			System.out.println("Given String is Positive");
			return true;
		}
		else
		{
			System.out.println("Given string is negative");
		    return false;
		}
	}
	public static void main(String[] args) {
		System.out.println("Enter a string");
		Scanner sc=new Scanner(System.in);
		str=sc.nextLine();
		Lab3_2 ld=new Lab3_2();
		ld.stringCheck(str);	
	}

}
