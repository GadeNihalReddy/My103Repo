package com.capgemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lab2_4 {
	 String FirstName;
	 String LastName;
	 char Gender;
	 String Mno;
	
	public void setDetails(String FirstName,String LastName,char Gender,String Mno)
	{
		this.FirstName = FirstName;
		this.LastName = LastName;
		this.Gender = Gender;
		this.Mno=Mno;
	}
	public void getDetails()
	{
		System.out.println("First Name: "+FirstName);
		System.out.println("Last Name: "+LastName);
		System.out.println("Gender: "+Gender);
		System.out.println("Mno: "+ Mno);
		
	}
	
	public static void main(String[] args) {
		Lab2_4 P=new Lab2_4();
		
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		
		try {
			System.out.println("Enter FirstName");
			String FirstName= br.readLine();
			System.out.println("Enter LasttName");
			String LastName = br.readLine();
			System.out.println("Enter Gender");
			char Gender = (char)br.read();
			br.readLine();
			System.out.println("Enter MobileNumber");
			String Mno=br.readLine();
			
			
			P.setDetails(FirstName,LastName,Gender,Mno);
			P.getDetails();
			//P.setFirstName(FirstName);
			//P.setLastName(LastName);
			//P.setGender(Gender);
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		

	}

}
