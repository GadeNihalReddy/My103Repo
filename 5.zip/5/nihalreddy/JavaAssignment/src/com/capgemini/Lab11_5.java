package com.capgemini;

import java.util.Scanner;

public class Lab11_5 implements Lab11_5Interface{
	int n;
	@Override
	public void fact(int n) {
		int fact =1;
		for(int i=n;i>=1;i--)
		{
			fact = fact*i;
		}
		System.out.println("factorial is : " + fact);
	}
	
	
	public Lab11_5(int n) {
		super();
		this.n = n;
		fact(n);
	}
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number");
		int number = sc.nextInt();
		Lab11_5Interface fact = Lab11_5::new;
		fact.fact(number);
	}


}
