package com.capgemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lab11_1 implements Lab11_1Interface{

	public static void main(String[] args) {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter x and y values:");
		try {
			double x=Double.parseDouble(br.readLine());
			double y=Double.parseDouble(br.readLine());
			
			Lab11_1Interface e=(num1,num2) ->{
				return Math.pow(num1,num2);
				
			};
			double result=e.power(x,y);
			System.out.println("Result: "+result);
			
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public double power(double x, double y) {
		
		return 0;
	}

}
