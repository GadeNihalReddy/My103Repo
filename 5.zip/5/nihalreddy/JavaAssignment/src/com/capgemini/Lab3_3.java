package com.capgemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Lab3_3 {
	static String str;
	public Period period(String str)
	{
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate start=LocalDate.parse(str,format);
		LocalDate end=LocalDate.now();
		Period p=start.until(end);
		return p;
		
	}
	public static void main(String[] args) {
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		try {
			System.out.println("Enter Date :");
			String str=br.readLine();
			Lab3_3 dt=new Lab3_3();
			
//			System.out.println("Days "+dt.period(str).get(ChronoUnit.DAYS));
//			System.out.println("Months "+dt.period(str).get(ChronoUnit.MONTHS));
//			System.out.println("Years "+dt.period(str).get(ChronoUnit.YEARS));
			System.out.println("Days "+dt.period(str).getDays());
			System.out.println("Months "+dt.period(str).getMonths());
			System.out.println("Years "+dt.period(str).getYears());
			
			} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}

}
