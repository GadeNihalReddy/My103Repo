package com.capgemini;

public class Account extends Person{
	private Long accNum;
	private double balance=500;
	private Person accHolder; 
	public void deposite(double x)
	{
		
	}
	public void withdraw(double y)
	{
		
	}
	public double getBalance()
	{
		return 0;
	}
	public Long getAccNum() {
		return accNum;
	}
	public void setAccNum(Long accNum) {
		this.accNum = accNum;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Account(String Name, float age, Long accNum, double balance, Person accHolder) {
		super(Name, age);
		this.accNum = accNum;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	public Account(String Name, float age) {
		super(Name, age);
	}
	
	
}
