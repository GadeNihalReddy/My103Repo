package com.capgemini;

public interface Lab11_3Interface {
	boolean valid(String user,String paswrsd);
}
