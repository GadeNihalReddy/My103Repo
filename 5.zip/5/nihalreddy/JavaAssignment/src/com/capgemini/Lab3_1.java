package com.capgemini;

import java.util.Scanner;

public class Lab3_1 {
	static String str;
	public void operations(String str,int i)
	{
		switch (i) {
		case 1:
			
			m1(str);
			
			break;
		case 2:
			m2(str);
			break;
		case 3:
			m3(str);
			break;
		case 4:
			m4(str);
			break;
		default:
			
			break;
		}
	}
	public void m4(String str2) {
        StringBuffer sb=new StringBuffer(str2);
		
		for(int i=0;i<sb.length();i+=2)
		{
			sb.setCharAt(i,(char) (sb.charAt(i)-32));
		}
		String s=new String(sb);
		System.out.println(s);
		
	}
	public void m3(String str2) {
		StringBuffer sb=new StringBuffer(str2);
		for(int i=0;i<sb.length();i++)
		{
			for(int j=i+1;j<sb.length();j++)
			{
				if(sb.charAt(i)==sb.charAt(j))
						{
							sb.deleteCharAt(j);
							j--;
							
						}
			}
		}
		System.out.println(sb.toString());
	}
	public void m2(String str2) {
		StringBuffer sb=new StringBuffer(str2);
		
		for(int i=0;i<sb.length();i+=2)
		{
			sb.setCharAt(i, '#');
		}
		String s=new String(sb);
		System.out.println(s);
		
	}
	public  void m1(String str2) {
		str2=str2+str2;
		System.out.println(str2);
		
	}
	public static void main(String[] args) {
		String string;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		string=sc.nextLine();
		str=string;
		int key;
		System.out.println("Enter the choice\n1.Add string to itself\n"
				+ "2.Replace odd positions with #\n"
				+ "3.Remove duplicate characters in the string\n"
				+ "4.Change Odd characters to upper case");
		Scanner sc1=new Scanner(System.in);
		key=Integer.parseInt(sc.nextLine());
		Lab3_1 lb=new Lab3_1();
		lb.operations(str, key);
		
		
		

	}

}
