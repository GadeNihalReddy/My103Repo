package com.capgemini;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Lab8_1 {

	public static void main(String[] args) throws FileNotFoundException {
		FileInputStream fis=new FileInputStream("source.txt");
		FileOutputStream fos=new FileOutputStream("target.txt");
		CopyDataThread copyFileThread=new CopyDataThread(fis,fos);
		copyFileThread.start();
	}

}
