package com.capgemini;

import java.time.LocalDateTime;

public class Lab8_2 implements Runnable {
	@Override
	public void run() {
		while (true) {
			LocalDateTime ld = LocalDateTime.now();
			System.out.println(ld);

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {

		Lab8_2 th = new Lab8_2();
		Thread t1 = new Thread(th);
		t1.start();
	}

}
