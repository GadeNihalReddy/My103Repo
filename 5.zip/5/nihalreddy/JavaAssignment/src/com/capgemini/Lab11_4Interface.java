package com.capgemini;

public interface Lab11_4Interface {
	
	public abstract Lab11_4_1 getLambdaImpl(int id , String name , int age);

}
