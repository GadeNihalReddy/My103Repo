package com.capgemini;

public interface Lab11_2Interface {
	 String stringFormat(String str);
}
