package com.capgemini;

public class FactThread extends Thread{
	int num;
	public FactThread(int num)
	{
		this.num=num;
	}
	public void run()
	{
		long fact=1;
		for(int i=1;i<=num;i++)
		{
			fact*=i;
		}
		System.out.println("Factorial of "+num+":"+fact);
	}
}
