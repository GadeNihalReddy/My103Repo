package com.capgemini;



class customer extends Thread
{
	@Override
	public void run() 
	{
		System.out.println("Customer giving products to billing person");
		super.run();
	}
}


class Biller extends Thread
{
	@Override
	public void run() 
	{
		System.out.println("Billing person bills the products.");
		super.run();
	}
}

public class CustomerBill 
{
	public static void main(String[] args) throws InterruptedException 
	{
		for(int i=0;i<5;i++){
		customer cc = new customer();
		Thread t1 = new Thread(cc);
		t1.start();
		
		Thread.sleep(1000);
		
		Biller bb = new Biller();
		Thread t2 = new Thread(bb);
		t2.start();
		Thread.sleep(1000);
		}
		
	}
}
