package com.capgemini;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Lab7_5 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		ArrayList<String> li=new ArrayList<String>();
		for(int i=0;i<n;i++)
		{
		
			li.add(sc.next());
		}
		Collections.sort(li);
		for (String str : li) 
		{
			System.out.println(str);
			
		}
	}

}
