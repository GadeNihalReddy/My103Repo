package com.capgemini;


@FunctionalInterface
public interface Lab11_1Interface {
	double power(double num1,double num2);

}
