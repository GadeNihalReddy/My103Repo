package com.capgemini;

public class Lab2_2 {

	public static void main(String[] args) {
		
		int j=Integer.parseInt(args[0]);
		if(j>=0)
		{
			System.out.println("Entered number is positive");
		}
		else
			System.out.println("Entered number is negative");
		

	}

}
