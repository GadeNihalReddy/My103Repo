package com.capgemini;

import java.util.Arrays;
import java.util.Scanner;

public class Lab3_8 {
	
	public static String[] m1(String[] str1)
	{
		Arrays.sort(str1);
		int len=(str1.length)%2;
		if(len!=0)
		{
			for(int i=0;i<(str1.length/2)+1;i++)
				str1[i]=str1[i].toUpperCase();
		}
		else
		{
			for(int i=0;i<(str1.length/2);i++)
			str1[i]=str1[i].toUpperCase();
		}
		return str1;
	}

	public static void main(String[] args) 
	{
		System.out.println("Enter the length of an array");
		Scanner sc =new Scanner(System.in);
		int n=sc.nextInt();
		String[] str=new String[n];
		for(int i=0;i<n;i++)
		{
			str[i]=sc.next();
		}
		System.out.println(Arrays.toString(m1(str)));
	}

}
