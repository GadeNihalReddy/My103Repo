package com.capgemini;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Lab11_2 {

	public static void main(String[] args) {
		System.out.println("Enter input string: ");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		try
		{
			String inputString =br.readLine();
			StringBuilder sb=new StringBuilder();
			Lab11_2Interface s=(str)->{
				sb.append(str);
				for(int i=1;i<sb.length();i++)
				{
					sb.insert(i,' ');
					i++;
				}
				return sb.toString();
			};
			System.out.println("New String "+s.stringFormat(inputString));
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}
