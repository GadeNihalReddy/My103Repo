package com.capgemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lab2_5 {
	enum Gender{
		M,F;
	}

	public static void main(String[] args) {
		System.out.println("Enter gender");
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.println("Gender:"+Gender.valueOf(br.readLine()));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
