package com.capgemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lab11_3 {

	public static void main(String[] args) {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter user Name and Paswrd");
		String username="Nihal";
		String password="nikky";
		
		try {
			
			String username1=br.readLine();
			String password1=br.readLine();
			Lab11_3Interface v=(user,paswrd)->{
				if(user.equalsIgnoreCase(username)&&paswrd.equalsIgnoreCase(password))
					return true;
				else
						return false;
				
			};
			if(v.valid(username1, password1))
				System.out.println("Valid details");
			else
				System.out.println("Invalid details");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
