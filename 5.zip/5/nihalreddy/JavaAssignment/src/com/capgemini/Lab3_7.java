package com.capgemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lab3_7 {
	static String str;
	
	public boolean register(String str)
	{
		boolean k=false;
		if(str.endsWith("_job")&&(str.length()-4)>=8)
		{
			System.out.println("User requirements satisfied");
			k=true;
		}
		else {
			System.out.println("Please enter correct credentials");
			
		}
		return k;
	}
	public static void main(String[] args) {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter UserName :");
		try {
			String str1=br.readLine();
			Lab3_7 ob=new Lab3_7();
			System.out.println(ob.register(str1));
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
