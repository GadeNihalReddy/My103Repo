package com.capgemini;

class Lab11_4_1 implements Lab11_4Interface{

	int age;
	String name;
	int id;
	public Lab11_4_1(int age, String name, int id) {
		super();
		this.age = age;
		this.name = name;
		this.id = id;
		Person11_4 per = new Person11_4(age, name, id);
		System.out.println(per);
	}
	@Override
	public Lab11_4_1 getLambdaImpl(int id, String name, int age) {
		return null;
	}
}
public class Lab11_4
{
	public static void main(String[] args) 
	{
			Lab11_4Interface im = Lab11_4_1::new; 
			im.getLambdaImpl(21, "yash", 101);	
	}
}
