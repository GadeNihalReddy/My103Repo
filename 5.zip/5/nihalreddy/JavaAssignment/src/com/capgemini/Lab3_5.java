package com.capgemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Lab3_5 {
	
	public static LocalDate warrenty(String str,int wrr)
	{
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate p=LocalDate.parse(str,format);
		p=p.plusMonths(wrr);
		//LocalDate end=LocalDate.parse(str2,format);
		
		return p;
	}

	public static void main(String[] args) {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter purchase date and warrenty period of product");
		try {
			String str=br.readLine();
			int wrr=Integer.parseInt(br.readLine());
			LocalDate d=warrenty(str,wrr);
			DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
			System.out.println(d.format(format));
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
