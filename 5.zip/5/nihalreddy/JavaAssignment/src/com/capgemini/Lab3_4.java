package com.capgemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Lab3_4 {
	static String str1,str2;
	public Period between(String str1,String str2)
	{
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate start=LocalDate.parse(str1,format);
		LocalDate end=LocalDate.parse(str2,format);
		Period p=start.until(end);
		return p;
	}

	public static void main(String[] args) {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		try {
			System.out.println("Enter Date1 :");
			String str1=br.readLine();
			System.out.println("Enter Date2 :");
			String str2=br.readLine();
			Lab3_4 dt=new Lab3_4();
			System.out.println("Days "+dt.between(str1,str2).getDays());
			System.out.println("Months "+dt.between(str1,str2).getMonths());
			System.out.println("Years "+dt.between(str1,str2).getYears());
			
			
			} 
		catch (IOException e) 
		{
				e.printStackTrace();
			}

	}

}
