package com.capgemini.doctors.exception;

public class AgeException extends Exception {

	private String string;

	@Override
	public String toString() {
		return "AgeException [string=" + string + "]";
	}

	public AgeException(String string) {
		this.string = string;

	}

	private static final long serialVersionUID = 1L;

}
