package com.capgemini.doctors.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.AgeException;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.validateProblemName;

public class Client {
	static int appointmentId = 0;

	// Method for booking appointment with the doctor
	public static void bookAppointment() {
		String appointmentStatus = "DISAPPROVED";
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		DoctorAppointmentService service = new DoctorAppointmentService();
		validateProblemName validate = new validateProblemName();

		try {
			// Entering Details
			System.out.println("Enter Name of the patient :");
			String patientName = br.readLine();
			System.out.println("Enter Phone Number :");
			String phoneNumber = br.readLine();
			System.out.println("Enter Email :");
			String email = br.readLine();
			System.out.println("Enter Age");
			int age = Integer.parseInt(br.readLine());
			// UserDefined Exception for age
			try {
				if (age < 15) {
					throw new AgeException("Age should be greater than 15");
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.err.println("Age is Invalid");
				//System.exit(0);
			}
			System.out.println("Enter Gender");
			String gender = br.readLine();
			System.out.println("Enter Problem Name");
			String problemName = br.readLine();
			int appointmentId = (int) (Math.random() * 1234 + 9999);
			LocalDate appointmentDate = LocalDate.now();
			DoctorAppointment doctorAppointment = new DoctorAppointment();
			doctorAppointment.setPatientName(patientName);
			doctorAppointment.setPhoneNumber(phoneNumber);
			doctorAppointment.setEmail(email);
			doctorAppointment.setAge(age);
			doctorAppointment.setGender(gender);
			doctorAppointment.setProblemName(problemName);
			doctorAppointment.setAppointmentDate(appointmentDate);
			doctorAppointment.setAppointmentId(appointmentId);
			if (problemName.equalsIgnoreCase("Heart")) {
				doctorAppointment.setDoctorName("Dr.Brijesh Kumar");

			} else if (problemName.equalsIgnoreCase("Gynecology")) {
				doctorAppointment.setDoctorName("Dr.Sharda Singh");

			} else if (problemName.equalsIgnoreCase("Diabetes")) {
				doctorAppointment.setDoctorName("Dr.Heena Khan");

			} else if (problemName.equalsIgnoreCase("ENT")) {
				doctorAppointment.setDoctorName("Dr.Paras mal");

			} else if (problemName.equalsIgnoreCase("Bone")) {
				doctorAppointment.setDoctorName("Dr.Renuka Kher");
			} else if (problemName.equalsIgnoreCase("Dermatology")) {
				doctorAppointment.setDoctorName("Dr.Kanika Kapoor");
			}

			boolean isValidProblemName = validate.isValidProblemName(problemName);
			boolean isvalidPhoneNumber =validate.isValidPhoneNumber(phoneNumber);

			if (isValidProblemName&&isvalidPhoneNumber) {
				appointmentStatus = "APPROVED";
				doctorAppointment.setAppointmentStatus(appointmentStatus);
			} else {
				System.out.println("Your status is not Approved");
			}
			if (appointmentStatus.equalsIgnoreCase("APPROVED")) {

				service.addDoctorAppointmentDetails(doctorAppointment);
				System.out.println("Your Doctor Appointment has been succesfully registered,your appointmentId is:<"
						+ doctorAppointment.getAppointmentId() + ">");
				System.out.println(
						"Appointment Date and time, along with doctor's phone number will be shared shortly with you");
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	// Method for viewing the patient appointment
	public static void viewAppointment() {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		DoctorAppointmentService service = new DoctorAppointmentService();

		try {
			System.out.println("Enter the appointment Id :");
			int appointmentId = Integer.parseInt(br.readLine());
			if (service.getDoctorAppointmentDetails(appointmentId) == null) {
				System.err.println("AppointmentId is Not Found");
			} else {
				System.out.println(
						"Patient Name :" + service.getDoctorAppointmentDetails(appointmentId).getPatientName());
				System.out.println("Appointment Status :"
						+ service.getDoctorAppointmentDetails(appointmentId).getAppointmentStatus());
				System.out
						.println("Doctor Name :" + service.getDoctorAppointmentDetails(appointmentId).getDoctorName());
				System.out.println(
						"Appointment Date and time, along with doctor's phone number will be shared shortly with you");
			}
		} catch (NumberFormatException e) {

			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	//Main method
	public static void main(String[] args) {
		int choice = 0;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		do {
			System.out.println("*********Welcome to Quick Appointment Service Application**********");
			System.out.println("1)Book Doctor Appointment\n2)View Doctor Appointment\n3)Exit");

			try {
				System.out.println("Enter your choice");
				choice = Integer.parseInt(br.readLine());

				switch (choice) {
				case 1:
					bookAppointment();
					break;
				case 2:
					viewAppointment();
					break;
				case 3:
					System.out.println("ThankYou");
					System.exit(0);
				default:
					System.out.println("Enter correct choice");
					break;
				}
			} catch (NumberFormatException e) {

				e.printStackTrace();
			} catch (IOException e) {

				e.printStackTrace();
			}
		} while (choice != 3);

	}

}
