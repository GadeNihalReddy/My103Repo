package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Id:");
		int eid=sc.nextInt();
		
		System.out.println("Enter Name:");
		String ename=sc.next();
		
		System.out.println("Enter salary:");
		double esalary=sc.nextDouble();
		
		if(esalary<3000) {
			try {
				throw new EmployeeException("Enter proper Salary Details above 3000");
				
			}catch (EmployeeException e) {
				e.printStackTrace();
			}
		}
		Employee e1=new Employee();
		e1.setId(eid);
		e1.setName(ename);
		e1.setSalary(esalary);
		
		if(esalary>5000 && esalary<20000)
		{
			e1.setDesignation("System Associate");
			e1.setInsuranceScheme("Scheme C");
		}
		else if(esalary>=20000 && esalary<40000)
		{
			e1.setDesignation("Programmer");
			e1.setInsuranceScheme("Scheme B");
		}
		else if(esalary>=40000)
		{
			e1.setDesignation("Manager");
			e1.setInsuranceScheme("Scheme A");
		}
		else if(esalary<5000)
		{
			e1.setDesignation("Clerk");
			e1.setInsuranceScheme("No Scheme");
		}
		e1.showDetails();

	}

}
