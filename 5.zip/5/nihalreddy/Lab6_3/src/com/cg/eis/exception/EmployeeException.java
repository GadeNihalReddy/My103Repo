package com.cg.eis.exception;

public class EmployeeException extends Exception{

	private String string;

	public EmployeeException(String string) {
		this.string=string;
	}

	@Override
	public String toString() {
		return "EmployeeException [string=" + string + "]";
	}
	
	

}
