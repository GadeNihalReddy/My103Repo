package com.JUnitAssignment;

import java.util.Scanner;

class myException2 extends Exception {
	public String getMessage() {
		return "Entered Salary is less than 3000";
	}
}

public class ExceptionCheck {
	public static void main(String[] args) throws myException2 {
		System.out.println("enter the salary of the employee");
		Scanner sc = new Scanner(System.in);
		double salary = sc.nextDouble();
		sal(salary);
	}

	public static String sal(double salary) throws myException2 {

		if (salary < 3000) {
			throw new myException2();
		} else {
			return "salary is :- " + salary;
		}
	}
}
