package com.JUnitAssignment;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

public class DateTest {
	
	Date dt=new Date(6,12,2018);
	@Test
	
	public void testDate() {
		//pasd
		
		assertEquals(null,6,12,2018);
	}

	@Test
	
	public void testSetDay() {
		//pasd
		assertEquals(6,dt.getDay());
	}

	@Test
	
	public void testGetDay() {
		//pasd
		assertEquals(6,dt.getDay());
	}

	@Test
	
	public void testSetMonth() {
		//pasd
		//assertNull("nothing is returned", dt.setMonth(12));
		assertEquals(12,dt.getMonth());
	}

	@Test
	
	public void testGetMonth() {
		//pasd
		assertEquals(12,dt.getMonth());
	}

	@Test
	
	public void testSetYear() {
		//pasd
		assertEquals(2018,dt.getYear());
	}

	@Test
	
	public void testGetYear() {
		//pasd
		assertEquals(2018,dt.getYear());
	}

	@Test
	
	public void testToString() {
		//pasd
		assertEquals("Date is 6/12/2018",dt.toString());
	}

}
