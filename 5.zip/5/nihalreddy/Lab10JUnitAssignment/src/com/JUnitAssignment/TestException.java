

package com.JUnitAssignment;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestException 
{

	@Test(expected = myException2.class)
	public void exceptionTest() throws myException2
	{
		ExceptionCheck ec = new ExceptionCheck();
		assertEquals("1000", ExceptionCheck.sal(1000));
	}

	@Test(expected = myException2.class)
	public void exceptionTest1() throws myException2
	{
		ExceptionCheck ec = new ExceptionCheck();
		assertEquals("1000", ExceptionCheck.sal(12));
	}

}
