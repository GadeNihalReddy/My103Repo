package com.capg;

public class Account {
	private long accNumber;
	private double balance;
	private Person accHolder;
	public long getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(long accNumber) {
		this.accNumber = accNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public void deposite(double dep_amount)
	{
		balance+=dep_amount;
	}
	public void withdraw(double with_amount)
	{
		double minbalance=500;
		if(with_amount>minbalance)
			balance-=with_amount;
		
	}
public double getBalance1()
{
	return balance;
}
}
