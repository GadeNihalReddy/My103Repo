package com.capg;

public class Person extends Account{
	private String name;
	private float age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
public static void main(String[] args) {
	Person obj1=new Person();
	Person obj2=new Person();
	obj1.setName("Smith");
	System.out.println("Name:"+obj1.getName());
	obj1.setBalance(2000);
	System.out.println("Initial Balance :"+obj1.getBalance());
	obj2.setName("kathy");
	System.out.println("Name :"+obj2.getName());
	obj2.setBalance(3000);
	System.out.println("Initial Balance :"+obj2.getBalance());
	System.out.println("Depositing 2000 to "+obj1.getName());
	obj1.deposite(2000);
	System.out.println("Withdrawl of 2000 from "+obj2.getName());
	obj2.withdraw(2000);
	System.out.println("Updated balance for "+obj1.getName() +"is "+obj1.getBalance1());
	System.out.println("Updated balance for "+obj2.getName() +"is "+obj2.getBalance1());
	
	
	
	
	
	
	
	
	
	
}

}
