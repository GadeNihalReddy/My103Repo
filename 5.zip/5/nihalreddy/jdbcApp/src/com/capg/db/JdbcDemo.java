package com.capg.db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcDemo {

	public static void main(String[] args) {
		int n = 0;
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system",
					"Capgemini123");
			Statement stmt = conn.createStatement();
			// String insertQuery="insert into PRODUCT_INFO
			// values(1,'mobile',5000,'06-jul-18')";
			// n=stmt.executeUpdate(insertQuery);

			String selectQuery = "select * from product_info";

			ResultSet rs = stmt.executeQuery(selectQuery);

			while (rs.next()) {
				int pid = rs.getInt(1);
				String pname = rs.getString("pname");
				double price = rs.getDouble("price");
				Date dop = rs.getDate("dop");
				System.out.println(pid + " " + pname + " " + price + " " + dop);
			}
			conn.close();
			// stmt.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		// System.out.println(n+ "records inserted");
	}

}
