package com.capg.db;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;

public class CSDemo {

	public static void main(String[] args) {
		Connection conn=null;
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system",
					"Capgemini123");
			
			CallableStatement cstmt=conn.prepareCall("{call ?:=f1(?)}");
			cstmt.setInt(2, 2);
			
			cstmt.registerOutParameter(1, Types.VARCHAR);
			cstmt.execute();
			String pname=cstmt.getString(1);
			System.out.println(pname);
//			cstmt.setInt(1, 101);
//			cstmt.registerOutParameter(2, Types.NUMERIC);
//			cstmt.execute();
			//int result = cstmt.getInt(2);
//			double result=cstmt.getDouble(2);
//			
//			System.out.println(result+"is the price");
//			
//		boolean iscalled=cstmt.execute();
//		System.out.println("Is procedure called "+iscalled);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		

	}

}
