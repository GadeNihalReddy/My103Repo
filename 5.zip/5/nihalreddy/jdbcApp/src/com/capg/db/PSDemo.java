package com.capg.db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PSDemo {
	public static void main(String[] args) {
	int n = 0;
	Connection conn=null;
	try {
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

		conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system",
				"Capgemini123");
		
		//Statement stmt = conn.createStatement();
		//String insertQuery="insert into PRODUCT_INFO values(?,?,?,SYSDATE)";
		//String update="update product_info set pname=? where pid=?";
		
		//PreparedStatement psmt=conn.prepareStatement(insertQuery);
//		PreparedStatement psmt=conn.prepareStatement(update);
//		psmt.setString(1, "lorry");
	//	psmt.setInt(2, 101);
//		psmt.setInt(1, 101);
//		psmt.setString(2, "bike");
//		psmt.setDouble(3, 4000);
		
		//n=psmt.executeUpdate();

		String selectQuery = "select * from product_info where price > ?";
		
		String deleteQuery="delete from product _info where pid=?";
		
		//PreparedStatement psmt=conn.prepareStatement(selectQuery);
		PreparedStatement psmt=conn.prepareStatement(deleteQuery);
		psmt.setInt(1, 101);
		ResultSet rs = psmt.executeQuery();

		while (rs.next()) {
			int pid = rs.getInt(1);
			String pname = rs.getString("pname");
			double price = rs.getDouble("price");
			Date dop = rs.getDate("dop");
			System.out.println(pid + " " + pname + " " + price + " " + dop);
		}
		
		// stmt.close();
	} catch (SQLException e) {

		e.printStackTrace();
	}
	
	finally {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
//	 System.out.println(n+ "records inserted");
	System.out.println(n+ "records updated");
}

}
