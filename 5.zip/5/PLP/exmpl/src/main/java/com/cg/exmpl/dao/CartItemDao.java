package com.cg.exmpl.dao;

import com.cg.exmpl.model.Cart;
import com.cg.exmpl.model.CartItem;

public interface CartItemDao {

	void addCartItem(CartItem cartItem);
	void removeCartItem(String CartItemId);
	void removeAllCartItems(Cart cart);

}
