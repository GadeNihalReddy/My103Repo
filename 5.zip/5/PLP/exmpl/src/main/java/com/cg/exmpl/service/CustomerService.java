package com.cg.exmpl.service;

import java.util.List;

import com.cg.exmpl.model.Customer;

public interface CustomerService {

	void addCustomer(Customer customer);

	List<Customer> getAllCustomers();

	Customer getCustomerByemailId(String emailId);

}
