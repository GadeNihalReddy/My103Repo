package com.cg.exmpl.service;

import com.cg.exmpl.model.Queries;

public interface QueriesService {

	void addQuery(Queries queries);
}
