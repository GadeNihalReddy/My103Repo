package com.cg.exmpl.service;

import com.cg.exmpl.model.Cart;

public interface CartService {

	Cart getCartByCartId(String CartId);
}
