package com.cg.exmpl.dao;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.hibernate.SessionFactory;
import com.cg.exmpl.model.Queries;

@Repository
public class QueriesDaoImpl implements QueriesDao  {

	@Autowired
	private EntityManager sessionFactory;
	
	public void addQuery(Queries queries) {
		Session session =  ((SessionFactory) sessionFactory).openSession();
		session.save(queries);
		session.close();
	}

}
