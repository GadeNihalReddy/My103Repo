package com.cg.exmpl.dao;

import com.cg.exmpl.model.CustomerOrder;

public interface CustomerOrderDao {

	void addCustomerOrder(CustomerOrder customerOrder);
}
