package com.cg.exmpl.dao;

import java.util.List;

import com.cg.exmpl.model.Customer;

public interface CustomerDao {

	void addCustomer(Customer customer);

	List<Customer> getAllCustomers();

	Customer getCustomerByemailId(String emailId);

}
