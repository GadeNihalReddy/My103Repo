package com.cg.returnrefundfront;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReturnrefundfrontApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReturnrefundfrontApplication.class, args);
	}
}
