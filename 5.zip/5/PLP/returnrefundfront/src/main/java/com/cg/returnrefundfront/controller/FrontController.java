package com.cg.returnrefundfront.controller;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.returnrefundfront.bean.Orders;
import com.cg.returnrefundfront.bean.Products;

@RestController
public class FrontController {

	@RequestMapping("/orders")
	public ModelAndView getAllOrders() {
		RestTemplate rt=new RestTemplate();
		List<Orders> o=rt.getForObject("http://localhost:9096/getallorders", ArrayList.class);
		return new ModelAndView("show","ord",o);
	}
	
	@RequestMapping(value="/mod3132/{id}",method=RequestMethod.GET)
	public ModelAndView getOrder(@PathVariable("id") int id) {
		RestTemplate rt=new RestTemplate();
		
		Orders o=rt.getForObject("http://localhost:9096/getOrder?id="+id, Orders.class);
		LocalDate dt = o.getDate();
		System.out.println("Order date " + dt);
		LocalDate dt1 = LocalDate.now();
		System.out.println("Todays date is " + dt1);
		LocalDate d = dt.plusDays(30);
		System.out.println("Return disable date " + d);
		
		if (d.isAfter(dt1) || d.isEqual(dt1)) {
			return new ModelAndView("details","ord",o);
		}
		return new ModelAndView("details1","ord",o);
		
	}
	
	@RequestMapping(value = "mod3132/return/{id}", method = RequestMethod.GET)
	public ModelAndView returns(@PathVariable("id") int id) {
		RestTemplate rt=new RestTemplate();
		System.out.println(id);
		List<Orders> order=rt.getForObject("http://localhost:9096/deleteOrderById?id="+id, ArrayList.class);
		return new ModelAndView("reason","res",order);
	}
	
	
}
