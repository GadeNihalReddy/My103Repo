package com.cg.returnrefundfront.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FrontControllerJsp {

	
	@RequestMapping("/index")
	public String showProductByIdPage() {
		return "index";
	}
	@RequestMapping("/success")
	public String showDeatil() {
		return "success";
	}
}
