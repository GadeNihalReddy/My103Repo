package com.cg.mpms.DTO;

public class CustomerDTO 
{
	private String mobileNo;
	private String firstName;
	private String lastName;
	private String address;
	private String rentalPlan;
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getRentalPlan() {
		return rentalPlan;
	}
	public void setRentalPlan(String rentalPlan) {
		this.rentalPlan = rentalPlan;
	}
	@Override
	public String toString() {
		return "CustomerDTO [mobileNo=" + mobileNo + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", address=" + address
				+ ", rentalPlan=" + rentalPlan + "]";
	}
	public CustomerDTO(String mobileNo, String firstName, String lastName,
			String address, String rentalPlan) {
		super();
		this.mobileNo = mobileNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.rentalPlan = rentalPlan;
	}
	public CustomerDTO() {
		super();
	}
} 

