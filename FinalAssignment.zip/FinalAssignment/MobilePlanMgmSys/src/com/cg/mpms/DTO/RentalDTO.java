package com.cg.mpms.DTO;

public class RentalDTO
{
		private String rentalId;
		private int localMin;
		private int stdMin;
		private int smsCount;
		private int dataMb;
		private float rentalPrice;
		public RentalDTO(String rentalId, int localMin, int stdMin,
				int smsCount, int dataMb, float rentalPrice) {
			super();
			this.rentalId = rentalId;
			this.localMin = localMin;
			this.stdMin = stdMin;
			this.smsCount = smsCount;
			this.dataMb = dataMb;
			this.rentalPrice = rentalPrice;
		}
		public RentalDTO() {
			super();
		}
		@Override
		public String toString() {
			return "RentalDTO [rentalId=" + rentalId + ", localMin=" + localMin
					+ ", stdMin=" + stdMin + ", smsCount=" + smsCount
					+ ", dataMb=" + dataMb + ", rentalPrice=" + rentalPrice
					+ "]";
		}
		public String getRentalId() {
			return rentalId;
		}
		public void setRentalId(String rentalId) {
			this.rentalId = rentalId;
		}
		public int getLocalMin() {
			return localMin;
		}
		public void setLocalMin(int localMin) {
			this.localMin = localMin;
		}
		public int getStdMin() {
			return stdMin;
		}
		public void setStdMin(int stdMin) {
			this.stdMin = stdMin;
		}
		public int getSmsCount() {
			return smsCount;
		}
		public void setSmsCount(int smsCount) {
			this.smsCount = smsCount;
		}
		public int getDataMb() {
			return dataMb;
		}
		public void setDataMb(int dataMb) {
			this.dataMb = dataMb;
		}
		public float getRentalPrice() {
			return rentalPrice;
		}
		public void setRentalPrice(float rentalPrice) {
			this.rentalPrice = rentalPrice;
		}
		public RentalDTO(String rentalId) {
			super();
			this.rentalId = rentalId;
		}
		
}
