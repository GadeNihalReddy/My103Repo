package com.cg.mpms.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.mpms.exception.MobileException;

public class DBUtil {
	public static Connection getCon() throws MobileException
	{
		InitialContext ic=null;;
		Connection connection=null;
		DataSource ds=null;
		try {
			ic = new InitialContext();
			ds=(DataSource) ic.lookup("java:/OracleDS");
		} catch (NamingException e) {
			throw new MobileException("message from DB/NamingExc:"+e.getMessage());
		}
		try {
			connection=ds.getConnection();
		} catch (SQLException e) {
			throw new MobileException("SQL Error:"+e.getMessage());
		}
		return connection;
	}
	
}
