package com.cg.mpms.service;

import java.util.ArrayList;

import com.cg.mpms.DTO.CustomerDTO;
import com.cg.mpms.DTO.RentalDTO;
import com.cg.mpms.exception.MobileException;

public interface IMobileService {
	public String insertCustomer(CustomerDTO cust) 
			throws MobileException;
	public RentalDTO showScheme(String schemeName)  
			throws MobileException;
	public ArrayList<RentalDTO> fetchSchemeName() 
			throws MobileException;
}
