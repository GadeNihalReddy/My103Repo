package com.cg.mpms.service;

import java.util.ArrayList;

import com.cg.mpms.DTO.CustomerDTO;
import com.cg.mpms.DTO.RentalDTO;
import com.cg.mpms.dao.IMobileDAO;
import com.cg.mpms.dao.MobileDAO;
import com.cg.mpms.exception.MobileException;

public class MobileService implements IMobileService{
	IMobileDAO mobdao=null;

	public MobileService() {
		super();
		mobdao =new MobileDAO();	
	}

	@Override
	public String insertCustomer(CustomerDTO cust) throws MobileException {
		
		return mobdao.insertCustomer(cust);
	}

	@Override
	public RentalDTO showScheme(String schemeName) throws MobileException {
		
		return mobdao.showScheme(schemeName);
	}

	@Override
	public ArrayList<RentalDTO> fetchSchemeName() throws MobileException {
		
		return mobdao.fetchSchemeName();
	}
	
}
