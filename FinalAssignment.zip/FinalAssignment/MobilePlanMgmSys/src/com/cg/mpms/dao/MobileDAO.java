package com.cg.mpms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.*;
import java.util.ArrayList;

import com.cg.mpms.DTO.CustomerDTO;
import com.cg.mpms.DTO.RentalDTO;
import com.cg.mpms.exception.MobileException;
import com.cg.mpms.util.DBUtil;

public class MobileDAO implements IMobileDAO{

	private ArrayList<RentalDTO> plans;

	@Override
	public String insertCustomer(CustomerDTO cust) throws MobileException {
		
		String plan=null;
		try 
		{
			Connection con=DBUtil.getCon();
			PreparedStatement pst=con.prepareStatement(QueryMapper.INSERTQUERY);
			pst.setString(1, cust.getMobileNo());
			pst.setString(2, cust.getFirstName());
			pst.setString(3, cust.getLastName());
			pst.setString(4, cust.getAddress());
			pst.setString(5, cust.getRentalPlan());
			int checker=pst.executeUpdate();
			if(checker!=0)
			{
				plan=cust.getRentalPlan();
			}
		}
		catch (Exception e) 
		{
			throw new MobileException("extra column added");
		} 
		return plan;
	}

	@Override
	public RentalDTO showScheme(String schemeName) throws MobileException {
		
		RentalDTO rent=null;
		try 
		{
			Connection con=DBUtil.getCon();
			PreparedStatement pst=con.prepareStatement(QueryMapper.SELECTQUERY);
			pst.setString(1, schemeName);
			ResultSet rs=pst.executeQuery();
			rs.next();
			rent=new RentalDTO(rs.getString("rental_id"),rs.getInt("local_min"),
					rs.getInt("std_min"),rs.getInt("sms_count"),rs.getInt("data_mb"),
					rs.getInt("rental_price"));
			
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return rent;
	}

	@Override
	public ArrayList<RentalDTO> fetchSchemeName() throws MobileException {
		
		plans = new ArrayList<RentalDTO>();
		RentalDTO rdto=null;
		
		try 
		{
			Connection con= DBUtil.getCon();
			PreparedStatement pst=con.prepareStatement(QueryMapper.SELECTNAMEQUERY);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				rdto= new RentalDTO(rs.getString("rental_id"));
				plans.add(rdto);
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return plans;
	}

}
