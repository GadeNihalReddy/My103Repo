package com.cg.mpms.dao;

public class QueryMapper
{
	public static final String INSERTQUERY="INSERT INTO customers (mobile_no,first_name,last_name,address,rental_id) VALUES(?,?,?,?,?)";
	public static final String SELECTQUERY="SELECT * FROM rental_plan WHERE rental_id=?";
	public static final String SELECTNAMEQUERY="SELECT rental_id FROM rental_plan";
} 