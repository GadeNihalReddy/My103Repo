package com.cg.mpms.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.mpms.DTO.CustomerDTO;
import com.cg.mpms.DTO.RentalDTO;
import com.cg.mpms.exception.MobileException;
import com.cg.mpms.service.IMobileService;
import com.cg.mpms.service.MobileService;


@WebServlet("*.do")
public class MobileController extends HttpServlet {
	String target=null;
	String path=null;
	private IMobileService mobser=null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		mobser=new MobileService();
		path=request.getServletPath();
		CustomerDTO csdto=null;
		RentalDTO rtldto=null;
		switch(path)
		{
		case "/addcustomer.do":		
			try {
				ArrayList<RentalDTO> rentalList = mobser.fetchSchemeName();
				request.setAttribute("rentalList", rentalList);
				target="addcustomer.jsp";
			} catch (MobileException e) {
				request.setAttribute("eMsg", e.getMessage());
				target="mobileerror.jsp";
			}
			break;
		case "/addcustdetails.do":
			String fname=request.getParameter("fname");
			String lname=request.getParameter("lname");
			String address=request.getParameter("address");
			String mobilenum=request.getParameter("mobnum");
			String rentalscheme=request.getParameter("rentscheme");
			csdto=new CustomerDTO(mobilenum,fname,lname,address,rentalscheme);
			try {
				mobser.insertCustomer(csdto);
				rtldto=mobser.showScheme(rentalscheme);
				request.setAttribute("csdto", csdto);
				request.setAttribute("plandetails", rtldto);
				target="customerplandetails.jsp";
			} catch (MobileException e) {
				request.setAttribute("eMsg", e.getMessage());
				target="mobileerror.jsp";
			}
			break;
		default:System.exit(0);
		}
		request.getRequestDispatcher(target).forward(request, response);
	}
    

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
